<!DOCTYPE html>
<html lang="en">
<head>

  <title>Dhaka Hospital</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <script src="assets/js/jquery.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="assets/css/style2.css">
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">
	  <span class="glyphicon glyphicon-plus-sign"></span>
	  Dhaka Hospital</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#about">About</a></li>
		<li><a href="#service">Services</a></li>
        <li><a href="#department">Department</a></li>
        <li><a href="#doctors">Doctors</a></li>
        <li><a href="#appointment">Log in</a></li>
        <li><a href="#contact">Contact us</a></li>
      </ul>
    </div>
  </div>
</nav>
<!--cAROSAL-->
<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
      <div class="item active">
        <img src="img/hos_1.jpg" alt="hospital" style="width:100%;height:100%;">
      </div>

      <div class="item">
        <img src="img/hos_3.png" alt="hospital" style="width:100%;height:100%;">
      </div>
    
      <div class="item">
        <img src="img/hos_2.jpg" alt="hospital" style="width:100%;height:100%;">
      </div>
    </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- CARASOL END-->

<!-- Container (About Section) -->
<div id="about" class="container-fluid">
  <div class="row">
    <div class="col-sm-8">
      <h2>About Dhaka Hospital</h2><br>
      <h4>Dhaka Hospital with its specialized clinical departments is one of the leading medical centers in Bangladesh and South Asia.
      Every year, hundreds of thousands of patients from all over Bangladesh and  other countries come here to make use of our modern treatment facilities. The highest standards of medical care are guaranteed by our world-renowned distinguished physicians and committed nursing staff. Dhaka Hospital is fully devoted for the benefit of all patients.</p>

      <br><button class="btn btn-default btn-lg" href="appointment">
	  <a href="login.php">
	  Create an Appointment</a></button>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-plus-sign logo-right"></span>
    </div>
  </div>
</div>

<div class="container-fluid bg-grey">
  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-globe logo slideanim"></span>
    </div>
    <div class="col-sm-8">
      <h2>Our Values</h2><br>
      <h4><strong>MISSION:</strong>Our mission is to enhance lives and preserve health by enabling access to a comprehensive, fully integrated network of the highest quality and most affordable care, delivered with kindness, integrity and respect.</h4><br>
      <strong>VISION:</strong> Our vision is to lead the evolution of healthcare to enable every member of the communities we serve to enjoy a better, healthier life.
    </div>
  </div>
</div>

<!-- Container (Services Section) -->
<div id="service" class="container-fluid text-center">
  <h2>SERVICES</h2>
  <h4>What we offer</h4>

                <div class="row">
				
 
               
                    <div class="col-sm-6 col-md-4">
                        <div class="service-grid">
                            <div class="service-icon">
                                  <img src="img/Service-24HourCare.png" class="logo-s">
                            </div>
                            <div class="service-text">
                                <h4>Call Center 24/7</h4>
                                <p>We are open 24 hours and 7 days a week to ensure your good health</p>
                            </div>
                        </div>
                    </div>
 
               
                    <div class="col-sm-6 col-md-4">
                        <div class="service-grid">
                            <div class="service-icon">
                                  <img src="img/medical-1.png" class="logo-s">
                            </div>
                            <div class="service-text">
                                <h4>Emergency Care</h4>
                                <p>Dhaka Hospital`s Emergency Care became the best in the country by delivering excellent healthcare,
								with respect and dignity to all patients needing emergent or urgent care services</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6 col-md-4">
                        <div class="service-grid">
                            <div class="service-icon">
                                  <img src="img/icon_01.png" class="logo-s">
                            </div>
                            <div class="service-text">
                                <h4>Qualified Doctors</h4>
                                <p>	We have some of the best doctors in whole of South-East Asia</p>
                            </div>
                        </div>
                    </div>
 
               

        
                </div>
</div>
<!-- container deparments -->
<div id="department" class="container-fluid text-center">
  <h2>DEPARTment</h2>
  <h4>Our departments</h4>

                <div class="row">
				<div class="col-sm-6 col-md-4">
                <div class="service-grid">
					<div class="service-icon">
					<img src="img/eye-512-1.png" class="logo-s">
					</div>
									<div class="service-text">
                                <h4>Ophthalmology </h4>
                                <p>Ophthalmology is the branch of medicine that deals with the anatomy,
								physiology and diseases of the eyeball and orbit.</p>
                            </div>
                        </div>
                    </div>
 
               
                    <div class="col-sm-6 col-md-4">
                        <div class="service-grid">
                            <div class="service-icon">
                                  <img src="img/dentist.png" class="logo-s">
                            </div>
                            <div class="service-text">
                                <h4>Dentistry  </h4>
                                <P>Dentistry is a branch of medicine that consists of the
								study, diagnosis, prevention, and treatment of diseases, disorders and conditions of the oral cavity</P>
                            </div>
                        </div>
                    </div>
 
               
                    <div class="col-sm-6 col-md-4">
                        <div class="service-grid">
                            <div class="service-icon">
                                  <img src="img/hear-512.png" class="logo-s">
                            </div>
                            <div class="service-text">
                                <h4>Otorhinolaryngology </h4>
                                <p>Otorhinolaryngology is a surgical subspecialty within
								medicine that deals with conditions of the ear, nose, and throat (ENT) and related structures of the head and neck.</p>
                            </div>
                        </div>
                    </div>
 
               
                    <div class="col-sm-6 col-md-4">
                        <div class="service-grid">
                            <div class="service-icon">
                                  <img src="img/heart-512.png" class="logo-s">
                            </div>
                            <div class="service-text">
                                <h4>Cardoilogy</h4>
                                <p>Cardiology is a branch of medicine dealing with disorders of the heart as well as parts of the circulatory system.</p>
                            </div>
                        </div>
                    </div>
 
               
                    <div class="col-sm-6 col-md-4">
                        <div class="service-grid">
                            <div class="service-icon">
                                  <img src="img/Liver-2-512.png" class="logo-s">
                            </div>
                            <div class="service-text">
                                <h4>Hepatology</h4>
                                <p>Hepatology is the branch of medicine that incorporates the study of liver,
								gallbladder, biliary tree, and pancreas as well as management of their disorders.</p>
                            </div>
                        </div>
                    </div>
                </div>
</div>
<!-- Container Doctors -->
<div id="doctors" class="container-fluid text-center bg-grey">
  <h2>Our Doctors</h2><br>
  <h4>We have some of the most qualified doctors.</h4>
  <div class="row text-center slideanim">
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/doc1.jpg" alt="Doctor" width="400" height="300">
        <p><strong>Dr. Omar Ziad</strong></p>
        <p>Cadriologist</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/doc2.jpg" alt="Doctor" width="400" height="300">
        <p><strong>Dr. Drake Ramoray</strong></p>
        <p>Dentist</p>
      </div>
    </div>
        <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/doc3.jpg" alt="Doctor" width="400" height="300">
        <p><strong>Dr. Strange</strong></p>
        <p>Cardiologist</p>
      </div>
    </div>
	    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/doc4.jpg" alt="Doctor" width="400" height="300">
        <p><strong>Dr. Tahera Nazrin</strong></p>
        <p>Ophthalmologist</p>
      </div>
    </div>
	    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/doc5.jpg" alt="Doctor" width="400" height="300">
        <p><strong>Dr. Gregory House</strong></p>
        <p>Hepatologist</p>
      </div>
    </div>
	    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/doc6.jpg" alt="Doctor" width="400" height="300">
        <p><strong>Dr. Mahbub Ali</strong></p>
        <p>Otorhinolaryngologist</p>
      </div>
    </div>
  </div><br>
  
  

<!-- Container Appointment Section) -->
<div id="appointment" class="container-fluid">
  <div class="text-center">
    <h2>Log in</h2>
    <h4>Log in as patient to create an appointment and visit us</h4>
  </div>
  <div class="row slideanim">
    <div class="col-sm-6 col-xs-12">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
          <h1>Patient Login</h1>
        </div>
        <div class="panel-body">
		<h3>Login as patient</h3>
        </div>
        <div class="panel-footer">
 
          <a href="login.php" class="nolink"><button class="btn btn-lg ">Login</button></a>
        </div>
      </div>      
    </div>     
       
    <div class="col-sm-6 col-xs-12">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
          <h1>Adminstrator Login</h1>
        </div>
        <div class="panel-body">
          <p>
		  <h3>Login as admin</h3>
		  </p>
        </div>
        <div class="panel-footer">
          
          <a href="adminlogin.php" class="nolink"><button class="btn btn-lg">Login</button></a>
        </div>
      </div>      
    </div>    
  </div>
</div>

<!-- Container (Contact Section) -->
<div id="contact" class="container-fluid bg-grey">
  <h2 class="text-center">CONTACT</h2>
  <div class="row">
    <div class="col-sm-5">
      <p>Contact us, we will reach you as soon as possible.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span> Dhaka, Bangladesh</p>
      <p><span class="glyphicon glyphicon-phone"></span> +88 01911111111</p>
      <p><span class="glyphicon glyphicon-envelope"></span> info@dhakahospital.com.bd</p>
    </div>
    <div class="col-sm-7 slideanim">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default pull-right" type="submit">Send</button>
        </div>
      </div>
    </div>
  </div>
</div>

<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <p>Made By BRACU Students</p>
</footer>

<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
</body>
</html>